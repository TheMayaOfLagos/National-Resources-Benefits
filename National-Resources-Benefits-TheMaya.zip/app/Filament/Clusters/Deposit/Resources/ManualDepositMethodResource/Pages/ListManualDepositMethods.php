<?php

namespace App\Filament\Clusters\Deposit\Resources\ManualDepositMethodResource\Pages;

use App\Filament\Clusters\Deposit\Resources\ManualDepositMethodResource;
use Filament\Resources\Pages\ListRecords;

class ListManualDepositMethods extends ListRecords
{
    protected static string $resource = ManualDepositMethodResource::class;
}
