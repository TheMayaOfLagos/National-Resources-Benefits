<?php

namespace App\Filament\Clusters\Transfer\Resources\WireTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\WireTransferResource;
use Filament\Resources\Pages\ListRecords;

class ListWireTransfers extends ListRecords
{
    protected static string $resource = WireTransferResource::class;
}
