<?php

namespace App\Filament\Resources\FundingSourceResource\Pages;

use App\Filament\Resources\FundingSourceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFundingSource extends CreateRecord
{
    protected static string $resource = FundingSourceResource::class;
}
