<div>
    {{-- Redundant Buttons Removed --}}

    {{ $this->form }}

    <x-filament-actions::modals />
</div>
