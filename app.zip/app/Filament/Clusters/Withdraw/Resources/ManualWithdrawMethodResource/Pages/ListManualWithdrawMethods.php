<?php

namespace App\Filament\Clusters\Withdraw\Resources\ManualWithdrawMethodResource\Pages;

use App\Filament\Clusters\Withdraw\Resources\ManualWithdrawMethodResource;
use Filament\Resources\Pages\ListRecords;

class ListManualWithdrawMethods extends ListRecords
{
    protected static string $resource = ManualWithdrawMethodResource::class;
}
