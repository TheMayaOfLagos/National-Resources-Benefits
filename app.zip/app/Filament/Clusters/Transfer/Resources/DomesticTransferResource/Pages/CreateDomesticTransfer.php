<?php

namespace App\Filament\Clusters\Transfer\Resources\DomesticTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\DomesticTransferResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDomesticTransfer extends CreateRecord
{
    protected static string $resource = DomesticTransferResource::class;
}
