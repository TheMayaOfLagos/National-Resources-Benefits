<?php

namespace App\Filament\Clusters\Withdraw\Resources\WithdrawHistoryResource\Pages;

use App\Filament\Clusters\Withdraw\Resources\WithdrawHistoryResource;
use Filament\Resources\Pages\ListRecords;

class ListWithdrawHistory extends ListRecords
{
    protected static string $resource = WithdrawHistoryResource::class;
}
