<?php

namespace App\Filament\Clusters\Deposit\Resources\ManualDepositRequestResource\Pages;

use App\Filament\Clusters\Deposit\Resources\ManualDepositRequestResource;
use Filament\Resources\Pages\ManageRecords;

class ManageManualDepositRequests extends ManageRecords
{
    protected static string $resource = ManualDepositRequestResource::class;
}
