<x-filament-panels::page>
    <form wire:submit="submit">
        {{ $this->form }}

        <div class="flex justify-end mt-4">
            <x-filament::button type="submit" class="mt-4">
                Save Changes
            </x-filament::button>
        </div>
    </form>
</x-filament-panels::page>
