<?php

namespace App\Filament\Clusters\Withdraw\Resources\ManualWithdrawRequestResource\Pages;

use App\Filament\Clusters\Withdraw\Resources\ManualWithdrawRequestResource;
use Filament\Resources\Pages\ManageRecords;

class ManageManualWithdrawRequests extends ManageRecords
{
    protected static string $resource = ManualWithdrawRequestResource::class;
}
