<?php

namespace App\Filament\Clusters\Transfer\Resources\InterbankTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\InterbankTransferResource;
use Filament\Resources\Pages\CreateRecord;

class CreateInterbankTransfer extends CreateRecord
{
    protected static string $resource = InterbankTransferResource::class;
}
