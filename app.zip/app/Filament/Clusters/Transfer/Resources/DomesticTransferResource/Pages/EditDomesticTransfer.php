<?php

namespace App\Filament\Clusters\Transfer\Resources\DomesticTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\DomesticTransferResource;
use Filament\Resources\Pages\EditRecord;

class EditDomesticTransfer extends EditRecord
{
    protected static string $resource = DomesticTransferResource::class;
}
