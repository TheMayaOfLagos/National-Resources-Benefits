<?php

namespace App\Filament\Resources\WalletTypeResource\Pages;

use App\Filament\Resources\WalletTypeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWalletType extends CreateRecord
{
    protected static string $resource = WalletTypeResource::class;
}
