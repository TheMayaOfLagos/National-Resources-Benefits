<?php

namespace App\Filament\Resources\FundingCategoryResource\Pages;

use App\Filament\Resources\FundingCategoryResource;
use Filament\Resources\Pages\ListRecords;

class ListFundingCategories extends ListRecords
{
    protected static string $resource = FundingCategoryResource::class;
}
