<?php

namespace App\Filament\Clusters\Transfer\Resources\WireTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\WireTransferResource;
use Filament\Resources\Pages\CreateRecord;

class CreateWireTransfer extends CreateRecord
{
    protected static string $resource = WireTransferResource::class;
}
