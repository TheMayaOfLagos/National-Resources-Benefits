<?php

namespace App\Filament\Resources\FundingCategoryResource\Pages;

use App\Filament\Resources\FundingCategoryResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFundingCategory extends CreateRecord
{
    protected static string $resource = FundingCategoryResource::class;
}
