<?php

namespace App\Filament\Clusters\Deposit\Resources\DepositHistoryResource\Pages;

use App\Filament\Clusters\Deposit\Resources\DepositHistoryResource;
use Filament\Resources\Pages\ListRecords;

class ListDepositHistory extends ListRecords
{
    protected static string $resource = DepositHistoryResource::class;
}
