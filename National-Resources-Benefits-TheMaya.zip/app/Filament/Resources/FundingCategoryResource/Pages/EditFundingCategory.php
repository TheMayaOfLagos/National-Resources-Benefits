<?php

namespace App\Filament\Resources\FundingCategoryResource\Pages;

use App\Filament\Resources\FundingCategoryResource;
use Filament\Resources\Pages\EditRecord;

class EditFundingCategory extends EditRecord
{
    protected static string $resource = FundingCategoryResource::class;
}
