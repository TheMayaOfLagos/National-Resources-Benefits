<?php

namespace App\Filament\Clusters\Transfer\Resources\AccountToAccountTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\AccountToAccountTransferResource;
use Filament\Resources\Pages\EditRecord;

class EditAccountToAccountTransfer extends EditRecord
{
    protected static string $resource = AccountToAccountTransferResource::class;
}
