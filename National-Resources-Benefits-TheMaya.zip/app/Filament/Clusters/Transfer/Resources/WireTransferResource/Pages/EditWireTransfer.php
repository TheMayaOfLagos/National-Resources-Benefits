<?php

namespace App\Filament\Clusters\Transfer\Resources\WireTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\WireTransferResource;
use Filament\Resources\Pages\EditRecord;

class EditWireTransfer extends EditRecord
{
    protected static string $resource = WireTransferResource::class;
}
