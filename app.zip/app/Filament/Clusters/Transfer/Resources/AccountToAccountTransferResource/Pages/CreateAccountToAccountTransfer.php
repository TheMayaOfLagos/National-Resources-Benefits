<?php

namespace App\Filament\Clusters\Transfer\Resources\AccountToAccountTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\AccountToAccountTransferResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAccountToAccountTransfer extends CreateRecord
{
    protected static string $resource = AccountToAccountTransferResource::class;
}
