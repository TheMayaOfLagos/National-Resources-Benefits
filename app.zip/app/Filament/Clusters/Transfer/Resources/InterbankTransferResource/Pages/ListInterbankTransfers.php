<?php

namespace App\Filament\Clusters\Transfer\Resources\InterbankTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\InterbankTransferResource;
use Filament\Resources\Pages\ListRecords;

class ListInterbankTransfers extends ListRecords
{
    protected static string $resource = InterbankTransferResource::class;
}
