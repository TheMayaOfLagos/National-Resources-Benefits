<?php

namespace App\Filament\Clusters\Transfer\Resources\DomesticTransferResource\Pages;

use App\Filament\Clusters\Transfer\Resources\DomesticTransferResource;
use Filament\Resources\Pages\ListRecords;

class ListDomesticTransfers extends ListRecords
{
    protected static string $resource = DomesticTransferResource::class;
}
